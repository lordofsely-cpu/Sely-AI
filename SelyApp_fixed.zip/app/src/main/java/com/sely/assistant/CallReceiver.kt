package com.sely.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.ContactsContract
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return

        val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        val callerLabel = incomingNumber?.let { lookupName(context, it) } ?: incomingNumber ?: "someone"

        // Hand off to the wake service so it can announce AND listen for "pick up" —
        // this starts the service fresh even if always-listen wasn't already on.
        val serviceIntent = Intent(context, SelyWakeService::class.java).apply {
            action = "ANNOUNCE_CALL"
            putExtra("caller_label", callerLabel)
        }
        try {
            context.startForegroundService(serviceIntent)
        } catch (e: Exception) {
            // If this fails (rare OEM restrictions), the call just rings normally with no announcement
        }
    }

    private fun lookupName(context: Context, number: String): String? {
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS)
            != android.content.pm.PackageManager.PERMISSION_GRANTED) return null

        val uri = android.net.Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            android.net.Uri.encode(number)
        )
        val cursor = context.contentResolver.query(
            uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                return it.getString(it.getColumnIndexOrThrow(ContactsContract.PhoneLookup.DISPLAY_NAME))
            }
        }
        return null
    }
}
